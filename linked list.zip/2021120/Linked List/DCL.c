#include<stdio.h>
#include<stdlib.h>
struct node{
    int data;
    struct node *next;
    struct node *prev;
};
void InsertAtEnd(struct node**,struct node**,int);
void InsertAtBegin(struct node **,struct node**, int);
void InsertAfterK(struct node**,struct node**,int,int);
void InsertBeforeK(struct node**,struct node**,int,int);
void DeleteFromStart(struct node**,struct node**);
void DeleteFromEnd(struct node**,struct node**);
void DeleteK(struct node**,struct node**,int );

void display(struct node**head)                     //to display the remaining elements in linked list
{   struct node *itr=*head;
        while(itr->next!=*head)
        {
            printf("%d\n",itr->data);
            itr=itr->next;
        }
        printf("%d\n",itr->data);
}

void main()
{
    struct node *head=NULL,*tail=NULL;
    int choice,num,k;
    char ch;
    do{
        printf("\n\t\t\t\t\t\t**********************");
        printf("\nMenu: 1.insert at the start of linked list, 2.Insert at the end of linked list, 3.Insert after a given node, 4.Insert before a given node, 5.delete from the start, 6.Delete from the end, 7.Delete a given node\n");
        printf("\nenter your choice: ");
        scanf("%d",&choice);
        switch(choice)
        {
            case 1:     printf("\nEnter number to be added: ");
                        scanf("%d",&num);
                        InsertAtBegin(&head,&tail,num);
                        break;
            case 2:     printf("\nEnter number to be added: ");
                        scanf("%d",&num);
                        InsertAtEnd(&head,&tail,num);
                        break;
            case 3:     printf("\nEnter number to be added: ");
                        scanf("%d",&num);
                        printf("\nEnter number after which node has to be added: ");
                        scanf("%d",&k);
                        InsertAfterK(&head,&tail,num,k);
                        break;
            case 4:     printf("\nEnter number to be added: ");
                        scanf("%d",&num);
                        printf("\nEnter number before which node has to be added: ");
                        scanf("%d",&k);
                        InsertBeforeK(&head,&tail,num,k);
                        break;
            case 5:     DeleteFromStart(&head,&tail);
                        break;
            case 6:     DeleteFromEnd(&head,&tail);
                        break;
            case 7:     printf("\nEnter number to be deleted: ");
                        scanf("%d",&k);
                        DeleteK(&head,&tail,k);
                        break;
            default:    printf("\nYour choice is invalid\n");
                        break;
        }
        printf("\n\nDo you want to continue?(y/n): ");
        scanf(" %c",&ch);
    }while(ch=='y'||ch=='Y');
    printf("\nnumbers present in linked list are:  \n");
    display(&head);
    free(head);
    free(tail);
}

void InsertAtBegin(struct node**head,struct node**tail,int val)                               //insertion at the starting of linked list
{
    struct node *temp=(struct node*)malloc(sizeof(struct node));
    if(!temp)
    {
        printf("\nmemory is not allocated\n");
        return;
    }
    temp->data=val;
    temp->next=NULL;
    temp->prev=NULL;
    if(*head==NULL && *tail==NULL)                     //no node is present
    {
        *head=temp;                                   //first node is added
        *tail=temp;
        (*head)->next=*head;
        (*head)->prev=*head;
        printf("\nnumber is added");
        return;
    }
    if((*head)->next==*head)
    {
        temp->next=*head;
        (*head)->prev=temp;
        (*head)->next=temp;
        temp->prev=*head;
        *head=temp;
        printf("\nnumber is added");
        return;
    }
    temp->next=*head;
    temp->prev=*tail;
    (*head)->prev=temp;
    (*tail)->next=temp;
    *head=temp;
    printf("Number is added\n");
}

void InsertAtEnd(struct node**head,struct node**tail,int val)                                 //insertion of node at the end of linked list
{
    struct node *temp=(struct node*)malloc(sizeof(struct node));
    if(temp==NULL)                      //to check memory allocation
    {
        printf("Memory is not allocated\n");
        return;
    }
    temp->data=val;
    temp->next=NULL;
    temp->prev=NULL;
    if(*head==NULL && *tail==NULL)                     //no node present
    {
       *head=temp;
       *tail=temp;
       (*head)->prev=*head;
       (*tail)->next=*tail;
       printf("\nnumber is added");
       return;
    }
    (*tail)->next=temp;
    temp->prev=(*tail);
    (*head)->prev=temp;
    temp->next=*head;
    *tail=temp;
    printf("element is added\n");
}

void InsertAfterK(struct node**head,struct node**tail,int val,int k)                          //insertion of a node after a given value
{
    struct node *temp=(struct node*)malloc(sizeof(struct node));
    if(temp==NULL)
    {
        printf("Memory allocation failed\n");
        return;
    }
    temp->data=val;
    temp->next=NULL;
    temp->prev=NULL;
    if(*head==NULL && *tail==NULL)                     //no node present
    {
        printf("linked list is empty\n");
        return;
    }
    if((*head)->data==k)
    {
        if((*head)->next==NULL)         //single node present
        {
             (*tail)->next=temp;
             temp->prev=(*tail);
             (*head)->prev=temp;
             temp->next=*head;
             *tail=temp;
        }
    }
    struct node*itr=*head;
    while(itr->next!=*head && itr->data!=k)
        itr=itr->next;
    if(itr->data==k)
    {
        temp->next=itr->next;
        temp->prev=itr;
        itr->next->prev=temp;
        itr->next=temp;
        printf("\nnumber is added");
    }
    else
    {
        printf("Node not found\n");
    }
}

void InsertBeforeK(struct node**head,struct node**tail,int val,int k)                         //insertion of a given node before a given value
{
    struct node*temp=(struct node*)malloc(sizeof(struct node));
    if(temp==NULL)
    {
        printf("Memory is not allocated\n");
        return;
    }
    temp->data=val;
    temp->next=NULL;
    temp->prev=NULL;
    if(*head==NULL && *tail==NULL)                              //no node present
    {
        printf("\nlinked list is empty\n");
        return;
    }
   if((*head)->next==*head)                       
    {
        if((*head)->data==k)                  //single node present
        {
            temp->next=*head;
            (*head)->prev=temp;
            (*tail)->next=temp;
            temp->prev=*tail;
            *head=temp;
            printf("\nnumber is added");
            return;
        }
        else
        {
            printf("No such number is present\n");
        }
        return;
    }
    struct node *itr=*head;
    while(itr->next!=*head && itr->next->data!=k)
        itr=itr->next;
    if(itr->next->data==k)
    {
        temp->next=itr->next;
        temp->prev=itr;
        itr->next->prev=temp;
        itr->next=temp;
        printf("\nnumber is added");
    }
    else
    {
        printf("no such node is found\n");
    }
}

void DeleteFromStart(struct node**head,struct node**tail)                                     //deletion of a node from beginning
{
    if(*head==NULL && *tail==NULL)                         //no node present
    {
        printf("linked list is empty\n");
        return;
    }
    struct node *temp=*head;
    if((*head)->next==*head)
    {
        *head=NULL;
        *tail=NULL;
        free(temp);
        printf("element is deleted\n");
        return;
    }
    *head=(*head)->next;
    (*head)->prev=*tail;
    (*tail)->next=*head;
    printf("number is deleted\n");
    free(temp);
}

void DeleteFromEnd(struct node**head,struct node**tail)                                       //deletion of a node from the end
{
    if(*head==NULL && *tail==NULL)                         //no node present
    {
        printf("linked list is empty\n");
        return;
    }
    struct node *temp=*head;
    if((*head)->next==*head)                 //single node present
    {
        *head=NULL;
        *tail=NULL;
        free(temp);
        printf("element is deleted\n");
        return;
    }
    temp=*tail;
    (*tail)->prev->next=*head;
    (*head)->prev=(*tail)->prev;
    printf("element deleted\n");
    free(temp);
}

void DeleteK(struct node**head,struct node**tail,int k)                                       //deletion of node k
{
    struct node *temp=NULL;
    if(*head==NULL && *tail==NULL)                         //no node present
    {
        printf("linked list is empty\n");
        return;
    }
    if((*head)->next==*head)                 //single node present
    {
        if((*head)->data==k)
        {
            temp=*head;
            *tail=NULL;
            (*head)=NULL;
            printf("element deleted\n");
            free(temp);
        }
        else
        {
            printf("not found\n");
        }
        return;
    }
    struct node *itr=*head;
    while(itr->next!=*head && itr->data!=k)
        itr=itr->next;
    if(itr->data==k)
    {
        temp=itr;    
        itr->prev->next=itr->next;
        itr->next->prev=itr->prev;
        free(temp);
        printf("element deleted\n");
    }
    else
    {
        printf("not found\n");
    }
}

